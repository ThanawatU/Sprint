-- AlterTable
ALTER TABLE "AuditLog" ADD COLUMN     "expiresAt" TIMESTAMP(3);
