-- AlterTable
ALTER TABLE "Route" ADD COLUMN     "distanceMeters" INTEGER,
ADD COLUMN     "durationSeconds" INTEGER;
